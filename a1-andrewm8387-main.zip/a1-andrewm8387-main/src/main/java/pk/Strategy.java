package pk;

public enum Strategy {
    RANDOM, COMBO, BATTLE
}
