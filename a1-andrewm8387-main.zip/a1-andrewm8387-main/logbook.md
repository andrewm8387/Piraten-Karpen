2023-01-10
    Project setup
    Step 1
2023-01-11
    Backlog update
    Tested and commented cloned code
    Completed F01 and F02
    Added player class
    Added turns and scoring for gold and diamond rolls
    Added skulls end turn
    Finished the MVP and released it
    Step 2
2023-01-14
    Added logging
    Added way to change number of games run
2023-01-16
    Updated backlog
    Started adding command line args but its still broke
2023-01-17
    Command is ready to be handled once I figure it out but works without a command for now
    Added card interface and drawing as well as battle cards and battle strategy
2023-01-18
    Added monkey card
    Main part of the assignment is done but just need to fix command line
    Added gold, diamond, and skull cards
2023-01-21
    Added island of skulls
    Added full chest
2023-01-22
    Added some commenting and minor code fixes.
2023-01-23
    Added requirement that player must roll 2 dice at minimum each roll